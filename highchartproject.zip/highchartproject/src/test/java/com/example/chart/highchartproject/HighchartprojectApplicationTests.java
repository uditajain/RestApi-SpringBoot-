package com.example.chart.highchartproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HighchartprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
