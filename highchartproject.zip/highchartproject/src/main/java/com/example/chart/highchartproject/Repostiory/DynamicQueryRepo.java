package com.example.chart.highchartproject.Repostiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.chart.highchartproject.Domain.GroupParticipationTheme;

public interface DynamicQueryRepo extends JpaRepository<GroupParticipationTheme, Long> {


//@Query(value = "select tbl_organizer.name , tbl_organizer.description where (:org_id is null or tbl_organizer.id = :org_id)",nativeQuery = true)
//List<Object> getdata(@Param("org_id")Long org_id);
	
}
