package com.example.chart.highchartproject.Domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_group_participation")
public class GroupParticipation {
@Id
	Long id ;                                            
	String created_by;
	Date created_date ;                                     
	String last_modified_by;                                  
	Date last_modified_date ;                               
	Long adult_female;                                      
	Long adult_male;                                     
	Long children_female;                                   
	Long children_male;                                  
	String created_on;                                      
	Long female_transgender;                                
	String from_date ;                                        
	String generated_by;                                      
	Long group_id ;                                         
	Long male_transgender;                                  
	String participant_picture1;                              
	String remarks;                                           
	String to_date ;                                          
	Long total_adults;                                      
	Long total_children;                                    
	Long total_participants;                                
	Long total_transgender  ;                               
	Long activity;                                          
	Long awc;                                               
	Long block;                                             
	Long country;                                           
	Long district;                                          
	Long level;                                             
	Long state ;                                            
	Long village;                                           
	String department;                                        
	Long community_meetings_diarrhoea;                      
	Long counseling_sessions_anganwadi;                     
	Long defeat_diarrhoea_campaign;                         
	Long orszinc_camps_established ;                        
	Long ors_packets_distributed;                           
	Long people_participated_mopr_adult_female;             
	Long people_participated_mopr_adult_male;               
	Long people_participated_mopr_adult_total;              
	Long people_participated_mopr_child_female;             
	Long people_participated_mopr_child_male;               
	Long people_participated_mopr_child_total;              
	Long people_participated_mopr_total;                    
	Long people_participated_moud_adult_female;             
	Long people_participated_moud_adult_male;               
	Long people_participated_moud_adult_total;              
	Long people_participated_moud_child_female;             
	Long people_participated_moud_child_male;            
	Long people_participated_moud_child_total;              
	Long people_participated_moud_total;                    
	Long persons_attended_the_session_mwc_child_female;
	Long persons_attended_the_session_mwc_child_male;      
	Long persons_attended_the_session_mwc_child_total;     
	Long persons_attended_the_session_mwcd_adult_female ;  
	Long persons_attended_the_session_mwcd_adult_male  ;   
	Long persons_attended_the_session_mwcd_adult_total ;   
	Long persons_attended_the_session_mwcd_total ;         
	Long persons_participated_adult_female_mhfw ;          
	Long persons_participated_adult_male_mhfw  ;           
	Long persons_participated_adult_total_mhfw ;           
	Long persons_participated_child_female_mhfw  ;         
	Long persons_participated_child_male_mhfw;             
	Long persons_participated_child_total_mhfw ;           
	Long persons_participated_total_mhfw ;                 
	Long provided_ors_packets_in_health_facilities_female; 
	Long provided_ors_packets_in_health_facilities_male ;  
	Long provided_ors_packets_in_health_facilities_total ; 
	Long provided_zinc_tablets_in_health_facilities_female;
	Long provided_zinc_tablets_in_health_facilities_male ; 
	Long provided_zinc_tablets_in_health_facilities_total ;
	Long school_children_reachedessage_diarrhoea_female ;  
	Long school_children_reachedessage_diarrhoea_male;     
	Long school_children_reachedessage_diarrhoea_total ;   
	Long school_covered  ;                                 
	Long water_sample_test ;                               
	Long wells_disinfected  ;                              
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getLast_modified_by() {
		return last_modified_by;
	}
	public void setLast_modified_by(String last_modified_by) {
		this.last_modified_by = last_modified_by;
	}
	public Date getLast_modified_date() {
		return last_modified_date;
	}
	public void setLast_modified_date(Date last_modified_date) {
		this.last_modified_date = last_modified_date;
	}
	public Long getAdult_female() {
		return adult_female;
	}
	public void setAdult_female(Long adult_female) {
		this.adult_female = adult_female;
	}
	public Long getAdult_male() {
		return adult_male;
	}
	public void setAdult_male(Long adult_male) {
		this.adult_male = adult_male;
	}
	public Long getChildren_female() {
		return children_female;
	}
	public void setChildren_female(Long children_female) {
		this.children_female = children_female;
	}
	public Long getChildren_male() {
		return children_male;
	}
	public void setChildren_male(Long children_male) {
		this.children_male = children_male;
	}
	public String getCreated_on() {
		return created_on;
	}
	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}
	public Long getFemale_transgender() {
		return female_transgender;
	}
	public void setFemale_transgender(Long female_transgender) {
		this.female_transgender = female_transgender;
	}
	public String getFrom_date() {
		return from_date;
	}
	public void setFrom_date(String from_date) {
		this.from_date = from_date;
	}
	public String getGenerated_by() {
		return generated_by;
	}
	public void setGenerated_by(String generated_by) {
		this.generated_by = generated_by;
	}
	public Long getGroup_id() {
		return group_id;
	}
	public void setGroup_id(Long group_id) {
		this.group_id = group_id;
	}
	public Long getMale_transgender() {
		return male_transgender;
	}
	public void setMale_transgender(Long male_transgender) {
		this.male_transgender = male_transgender;
	}
	public String getParticipant_picture1() {
		return participant_picture1;
	}
	public void setParticipant_picture1(String participant_picture1) {
		this.participant_picture1 = participant_picture1;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTo_date() {
		return to_date;
	}
	public void setTo_date(String to_date) {
		this.to_date = to_date;
	}
	public Long getTotal_adults() {
		return total_adults;
	}
	public void setTotal_adults(Long total_adults) {
		this.total_adults = total_adults;
	}
	public Long getTotal_children() {
		return total_children;
	}
	public void setTotal_children(Long total_children) {
		this.total_children = total_children;
	}
	public Long getTotal_participants() {
		return total_participants;
	}
	public void setTotal_participants(Long total_participants) {
		this.total_participants = total_participants;
	}
	public Long getTotal_transgender() {
		return total_transgender;
	}
	public void setTotal_transgender(Long total_transgender) {
		this.total_transgender = total_transgender;
	}
	public Long getActivity() {
		return activity;
	}
	public void setActivity(Long activity) {
		this.activity = activity;
	}
	public Long getAwc() {
		return awc;
	}
	public void setAwc(Long awc) {
		this.awc = awc;
	}
	public Long getBlock() {
		return block;
	}
	public void setBlock(Long block) {
		this.block = block;
	}
	public Long getCountry() {
		return country;
	}
	public void setCountry(Long country) {
		this.country = country;
	}
	public Long getDistrict() {
		return district;
	}
	public void setDistrict(Long district) {
		this.district = district;
	}
	public Long getLevel() {
		return level;
	}
	public void setLevel(Long level) {
		this.level = level;
	}
	public Long getState() {
		return state;
	}
	public void setState(Long state) {
		this.state = state;
	}
	public Long getVillage() {
		return village;
	}
	public void setVillage(Long village) {
		this.village = village;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Long getCommunity_meetings_diarrhoea() {
		return community_meetings_diarrhoea;
	}
	public void setCommunity_meetings_diarrhoea(Long community_meetings_diarrhoea) {
		this.community_meetings_diarrhoea = community_meetings_diarrhoea;
	}
	public Long getCounseling_sessions_anganwadi() {
		return counseling_sessions_anganwadi;
	}
	public void setCounseling_sessions_anganwadi(Long counseling_sessions_anganwadi) {
		this.counseling_sessions_anganwadi = counseling_sessions_anganwadi;
	}
	public Long getDefeat_diarrhoea_campaign() {
		return defeat_diarrhoea_campaign;
	}
	public void setDefeat_diarrhoea_campaign(Long defeat_diarrhoea_campaign) {
		this.defeat_diarrhoea_campaign = defeat_diarrhoea_campaign;
	}
	public Long getOrszinc_camps_established() {
		return orszinc_camps_established;
	}
	public void setOrszinc_camps_established(Long orszinc_camps_established) {
		this.orszinc_camps_established = orszinc_camps_established;
	}
	public Long getOrs_packets_distributed() {
		return ors_packets_distributed;
	}
	public void setOrs_packets_distributed(Long ors_packets_distributed) {
		this.ors_packets_distributed = ors_packets_distributed;
	}
	public Long getPeople_participated_mopr_adult_female() {
		return people_participated_mopr_adult_female;
	}
	public void setPeople_participated_mopr_adult_female(Long people_participated_mopr_adult_female) {
		this.people_participated_mopr_adult_female = people_participated_mopr_adult_female;
	}
	public Long getPeople_participated_mopr_adult_male() {
		return people_participated_mopr_adult_male;
	}
	public void setPeople_participated_mopr_adult_male(Long people_participated_mopr_adult_male) {
		this.people_participated_mopr_adult_male = people_participated_mopr_adult_male;
	}
	public Long getPeople_participated_mopr_adult_total() {
		return people_participated_mopr_adult_total;
	}
	public void setPeople_participated_mopr_adult_total(Long people_participated_mopr_adult_total) {
		this.people_participated_mopr_adult_total = people_participated_mopr_adult_total;
	}
	public Long getPeople_participated_mopr_child_female() {
		return people_participated_mopr_child_female;
	}
	public void setPeople_participated_mopr_child_female(Long people_participated_mopr_child_female) {
		this.people_participated_mopr_child_female = people_participated_mopr_child_female;
	}
	public Long getPeople_participated_mopr_child_male() {
		return people_participated_mopr_child_male;
	}
	public void setPeople_participated_mopr_child_male(Long people_participated_mopr_child_male) {
		this.people_participated_mopr_child_male = people_participated_mopr_child_male;
	}
	public Long getPeople_participated_mopr_child_total() {
		return people_participated_mopr_child_total;
	}
	public void setPeople_participated_mopr_child_total(Long people_participated_mopr_child_total) {
		this.people_participated_mopr_child_total = people_participated_mopr_child_total;
	}
	public Long getPeople_participated_mopr_total() {
		return people_participated_mopr_total;
	}
	public void setPeople_participated_mopr_total(Long people_participated_mopr_total) {
		this.people_participated_mopr_total = people_participated_mopr_total;
	}
	public Long getPeople_participated_moud_adult_female() {
		return people_participated_moud_adult_female;
	}
	public void setPeople_participated_moud_adult_female(Long people_participated_moud_adult_female) {
		this.people_participated_moud_adult_female = people_participated_moud_adult_female;
	}
	public Long getPeople_participated_moud_adult_male() {
		return people_participated_moud_adult_male;
	}
	public void setPeople_participated_moud_adult_male(Long people_participated_moud_adult_male) {
		this.people_participated_moud_adult_male = people_participated_moud_adult_male;
	}
	public Long getPeople_participated_moud_adult_total() {
		return people_participated_moud_adult_total;
	}
	public void setPeople_participated_moud_adult_total(Long people_participated_moud_adult_total) {
		this.people_participated_moud_adult_total = people_participated_moud_adult_total;
	}
	public Long getPeople_participated_moud_child_female() {
		return people_participated_moud_child_female;
	}
	public void setPeople_participated_moud_child_female(Long people_participated_moud_child_female) {
		this.people_participated_moud_child_female = people_participated_moud_child_female;
	}
	public Long getPeople_participated_moud_child_male() {
		return people_participated_moud_child_male;
	}
	public void setPeople_participated_moud_child_male(Long people_participated_moud_child_male) {
		this.people_participated_moud_child_male = people_participated_moud_child_male;
	}
	public Long getPeople_participated_moud_child_total() {
		return people_participated_moud_child_total;
	}
	public void setPeople_participated_moud_child_total(Long people_participated_moud_child_total) {
		this.people_participated_moud_child_total = people_participated_moud_child_total;
	}
	public Long getPeople_participated_moud_total() {
		return people_participated_moud_total;
	}
	public void setPeople_participated_moud_total(Long people_participated_moud_total) {
		this.people_participated_moud_total = people_participated_moud_total;
	}
	public Long getPersons_attended_the_session_mwc_child_female() {
		return persons_attended_the_session_mwc_child_female;
	}
	public void setPersons_attended_the_session_mwc_child_female(Long persons_attended_the_session_mwc_child_female) {
		this.persons_attended_the_session_mwc_child_female = persons_attended_the_session_mwc_child_female;
	}
	public Long getPersons_attended_the_session_mwc_child_male() {
		return persons_attended_the_session_mwc_child_male;
	}
	public void setPersons_attended_the_session_mwc_child_male(Long persons_attended_the_session_mwc_child_male) {
		this.persons_attended_the_session_mwc_child_male = persons_attended_the_session_mwc_child_male;
	}
	public Long getPersons_attended_the_session_mwc_child_total() {
		return persons_attended_the_session_mwc_child_total;
	}
	public void setPersons_attended_the_session_mwc_child_total(Long persons_attended_the_session_mwc_child_total) {
		this.persons_attended_the_session_mwc_child_total = persons_attended_the_session_mwc_child_total;
	}
	public Long getPersons_attended_the_session_mwcd_adult_female() {
		return persons_attended_the_session_mwcd_adult_female;
	}
	public void setPersons_attended_the_session_mwcd_adult_female(Long persons_attended_the_session_mwcd_adult_female) {
		this.persons_attended_the_session_mwcd_adult_female = persons_attended_the_session_mwcd_adult_female;
	}
	public Long getPersons_attended_the_session_mwcd_adult_male() {
		return persons_attended_the_session_mwcd_adult_male;
	}
	public void setPersons_attended_the_session_mwcd_adult_male(Long persons_attended_the_session_mwcd_adult_male) {
		this.persons_attended_the_session_mwcd_adult_male = persons_attended_the_session_mwcd_adult_male;
	}
	public Long getPersons_attended_the_session_mwcd_adult_total() {
		return persons_attended_the_session_mwcd_adult_total;
	}
	public void setPersons_attended_the_session_mwcd_adult_total(Long persons_attended_the_session_mwcd_adult_total) {
		this.persons_attended_the_session_mwcd_adult_total = persons_attended_the_session_mwcd_adult_total;
	}
	public Long getPersons_attended_the_session_mwcd_total() {
		return persons_attended_the_session_mwcd_total;
	}
	public void setPersons_attended_the_session_mwcd_total(Long persons_attended_the_session_mwcd_total) {
		this.persons_attended_the_session_mwcd_total = persons_attended_the_session_mwcd_total;
	}
	public Long getPersons_participated_adult_female_mhfw() {
		return persons_participated_adult_female_mhfw;
	}
	public void setPersons_participated_adult_female_mhfw(Long persons_participated_adult_female_mhfw) {
		this.persons_participated_adult_female_mhfw = persons_participated_adult_female_mhfw;
	}
	public Long getPersons_participated_adult_male_mhfw() {
		return persons_participated_adult_male_mhfw;
	}
	public void setPersons_participated_adult_male_mhfw(Long persons_participated_adult_male_mhfw) {
		this.persons_participated_adult_male_mhfw = persons_participated_adult_male_mhfw;
	}
	public Long getPersons_participated_adult_total_mhfw() {
		return persons_participated_adult_total_mhfw;
	}
	public void setPersons_participated_adult_total_mhfw(Long persons_participated_adult_total_mhfw) {
		this.persons_participated_adult_total_mhfw = persons_participated_adult_total_mhfw;
	}
	public Long getPersons_participated_child_female_mhfw() {
		return persons_participated_child_female_mhfw;
	}
	public void setPersons_participated_child_female_mhfw(Long persons_participated_child_female_mhfw) {
		this.persons_participated_child_female_mhfw = persons_participated_child_female_mhfw;
	}
	public Long getPersons_participated_child_male_mhfw() {
		return persons_participated_child_male_mhfw;
	}
	public void setPersons_participated_child_male_mhfw(Long persons_participated_child_male_mhfw) {
		this.persons_participated_child_male_mhfw = persons_participated_child_male_mhfw;
	}
	public Long getPersons_participated_child_total_mhfw() {
		return persons_participated_child_total_mhfw;
	}
	public void setPersons_participated_child_total_mhfw(Long persons_participated_child_total_mhfw) {
		this.persons_participated_child_total_mhfw = persons_participated_child_total_mhfw;
	}
	public Long getPersons_participated_total_mhfw() {
		return persons_participated_total_mhfw;
	}
	public void setPersons_participated_total_mhfw(Long persons_participated_total_mhfw) {
		this.persons_participated_total_mhfw = persons_participated_total_mhfw;
	}
	public Long getProvided_ors_packets_in_health_facilities_female() {
		return provided_ors_packets_in_health_facilities_female;
	}
	public void setProvided_ors_packets_in_health_facilities_female(Long provided_ors_packets_in_health_facilities_female) {
		this.provided_ors_packets_in_health_facilities_female = provided_ors_packets_in_health_facilities_female;
	}
	public Long getProvided_ors_packets_in_health_facilities_male() {
		return provided_ors_packets_in_health_facilities_male;
	}
	public void setProvided_ors_packets_in_health_facilities_male(Long provided_ors_packets_in_health_facilities_male) {
		this.provided_ors_packets_in_health_facilities_male = provided_ors_packets_in_health_facilities_male;
	}
	public Long getProvided_ors_packets_in_health_facilities_total() {
		return provided_ors_packets_in_health_facilities_total;
	}
	public void setProvided_ors_packets_in_health_facilities_total(Long provided_ors_packets_in_health_facilities_total) {
		this.provided_ors_packets_in_health_facilities_total = provided_ors_packets_in_health_facilities_total;
	}
	public Long getProvided_zinc_tablets_in_health_facilities_female() {
		return provided_zinc_tablets_in_health_facilities_female;
	}
	public void setProvided_zinc_tablets_in_health_facilities_female(
			Long provided_zinc_tablets_in_health_facilities_female) {
		this.provided_zinc_tablets_in_health_facilities_female = provided_zinc_tablets_in_health_facilities_female;
	}
	public Long getProvided_zinc_tablets_in_health_facilities_male() {
		return provided_zinc_tablets_in_health_facilities_male;
	}
	public void setProvided_zinc_tablets_in_health_facilities_male(Long provided_zinc_tablets_in_health_facilities_male) {
		this.provided_zinc_tablets_in_health_facilities_male = provided_zinc_tablets_in_health_facilities_male;
	}
	public Long getProvided_zinc_tablets_in_health_facilities_total() {
		return provided_zinc_tablets_in_health_facilities_total;
	}
	public void setProvided_zinc_tablets_in_health_facilities_total(Long provided_zinc_tablets_in_health_facilities_total) {
		this.provided_zinc_tablets_in_health_facilities_total = provided_zinc_tablets_in_health_facilities_total;
	}
	public Long getSchool_children_reachedessage_diarrhoea_female() {
		return school_children_reachedessage_diarrhoea_female;
	}
	public void setSchool_children_reachedessage_diarrhoea_female(Long school_children_reachedessage_diarrhoea_female) {
		this.school_children_reachedessage_diarrhoea_female = school_children_reachedessage_diarrhoea_female;
	}
	public Long getSchool_children_reachedessage_diarrhoea_male() {
		return school_children_reachedessage_diarrhoea_male;
	}
	public void setSchool_children_reachedessage_diarrhoea_male(Long school_children_reachedessage_diarrhoea_male) {
		this.school_children_reachedessage_diarrhoea_male = school_children_reachedessage_diarrhoea_male;
	}
	public Long getSchool_children_reachedessage_diarrhoea_total() {
		return school_children_reachedessage_diarrhoea_total;
	}
	public void setSchool_children_reachedessage_diarrhoea_total(Long school_children_reachedessage_diarrhoea_total) {
		this.school_children_reachedessage_diarrhoea_total = school_children_reachedessage_diarrhoea_total;
	}
	public Long getSchool_covered() {
		return school_covered;
	}
	public void setSchool_covered(Long school_covered) {
		this.school_covered = school_covered;
	}
	public Long getWater_sample_test() {
		return water_sample_test;
	}
	public void setWater_sample_test(Long water_sample_test) {
		this.water_sample_test = water_sample_test;
	}
	public Long getWells_disinfected() {
		return wells_disinfected;
	}
	public void setWells_disinfected(Long wells_disinfected) {
		this.wells_disinfected = wells_disinfected;
	}
	public String getOther_activity_id() {
		return other_activity_id;
	}
	public void setOther_activity_id(String other_activity_id) {
		this.other_activity_id = other_activity_id;
	}
	String other_activity_id ;                               

}
