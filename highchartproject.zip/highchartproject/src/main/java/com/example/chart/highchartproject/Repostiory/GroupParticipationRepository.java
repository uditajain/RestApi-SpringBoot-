package com.example.chart.highchartproject.Repostiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.chart.highchartproject.Domain.GroupParticipation;

public interface GroupParticipationRepository extends JpaRepository<GroupParticipation, Long>{

}
