package com.example.chart.highchartproject.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.chart.highchartproject.Domain.Custom;
import com.example.chart.highchartproject.Domain.CustomData;
import com.example.chart.highchartproject.Domain.CustomOrg;
import com.example.chart.highchartproject.Domain.CustomOrgtheme;
import com.example.chart.highchartproject.Domain.CustomResult;
import com.example.chart.highchartproject.Domain.CustomTableData;
import com.example.chart.highchartproject.Domain.GetOrganizer;
import com.example.chart.highchartproject.Domain.GetTheme;
import com.example.chart.highchartproject.Domain.GroupParticipation;
import com.example.chart.highchartproject.Domain.GroupParticipationOrganizer;
import com.example.chart.highchartproject.Domain.GroupParticipationTheme;
import com.example.chart.highchartproject.Domain.Organizer;
import com.example.chart.highchartproject.Domain.Survey;
import com.example.chart.highchartproject.Domain.Theme;
import com.example.chart.highchartproject.Repostiory.CustomTable;
import com.example.chart.highchartproject.Repostiory.DynamicQueryRepo;
import com.example.chart.highchartproject.Repostiory.GroupParticipationOrganizerRepo;
import com.example.chart.highchartproject.Repostiory.GroupParticipationRepository;
import com.example.chart.highchartproject.Repostiory.GroupParticipationThemeRepo;
import com.example.chart.highchartproject.Repostiory.OrganizeRepo;
import com.example.chart.highchartproject.Repostiory.SurveyRepostiroy;
import com.example.chart.highchartproject.Repostiory.ThemeRepo;
//import com.org.itm.samast.Domain.SurveyQuestions;
@CrossOrigin(origins = "http://localhost:8080")


@RestController
public class SurveyController {
@Autowired
SurveyRepostiroy surveyrepository;
@Autowired
GroupParticipationRepository groupparticipationrepo;
@Autowired
GroupParticipationOrganizerRepo groupParticipationorganizerrepo;
@Autowired
GroupParticipationThemeRepo groupparticipationthemerepo;
@Autowired
ThemeRepo themerepo;
@Autowired
OrganizeRepo orgrepo;
@Autowired
DynamicQueryRepo dynamicqueryrepo;




@GetMapping("/get-group-participation")
public List<GroupParticipation> getAllgp() {
	return groupparticipationrepo.findAll();
}
@GetMapping("/get-group-participation-org")
public List<GroupParticipationOrganizer> getAllgpo() {
	return groupParticipationorganizerrepo.findAll();
}

@GetMapping("/get-group-participation-theme")
public List<CustomData> getAllgpt() {
	 List<CustomData> themes = groupparticipationthemerepo.getCountJoin();
return themes;
}
//@GetMapping("/get-group-participation-organizer")
//public List<CustomOrg> getAllorganizename() {
//	 List<CustomOrg> organizer = groupParticipationorganizerrepo.getCountt();
//return organizer;
//}

@GetMapping("/get-group-organizercount")
public List<CustomOrg> getAllcount() {
	 List<CustomOrg> themes = groupParticipationorganizerrepo.getorg();
return themes;
}




@RequestMapping(value = "/get-organizercountbyid",method = RequestMethod.POST)
public List<CustomOrg> getcountbyidorg(CustomOrgtheme obj) {
	Long org_id  = obj.getOrg_id();
	System.out.println(org_id);
	 List<CustomOrg> themes;
	if(obj.getOrg_id()==null) {

themes	 = groupParticipationorganizerrepo.getorg();
	}else {

themes	 = groupParticipationorganizerrepo.getCountt(org_id);
	}
	 return themes;
}






@RequestMapping(value = "/get-themecountbyid",method = RequestMethod.POST)
public List<CustomData> getcountbyidtheme(CustomOrgtheme obj) {
	Long theme_id  = obj.getTheme_id();
	System.out.println(theme_id);
	 List<CustomData> theme;
	if(obj.getTheme_id()==null) {
System.out.print("inifondition");
		theme = groupparticipationthemerepo.getCountJoin();
	}else {
	System.out.println("inelse");

		theme	 = groupparticipationthemerepo.getCountJoinbyid(theme_id);
	}
	 return theme;
}







@GetMapping("/get-organizer")
public List<GetOrganizer> getorg() {
	 List<GetOrganizer> names = orgrepo.getName();
	    return names;
    
    }


@GetMapping("/getcustomdata")
public List<Object> customdata(){
	List<Object> dataa = groupParticipationorganizerrepo.getdata(2);
	return dataa;
}
/*
 * @PostMapping("/get-theme-organizer") public List<CustomTable>
 * getQuestionsData(@RequestParam Map<String, String> body) { Integer limit =
 * reqObj.getLimit(); Integer offset = reqObj.getOffset(); List<CustomTable>
 * getData = groupParticipationorganizerrepo.getaa(offset,limit); return
 * getData; }
 * 
 */
//@PostMapping("/get-theme-organizer")
@RequestMapping(value = "/get-theme-organizer",method = RequestMethod.POST)
public List<CustomTable> getQuestionsData(CustomTableData obj) {
	Integer start  = obj.getStart();
	Integer length = obj.getLength();
//	Integer theme_id = obj.getTheme_id();
	System.out.println(start);
	 List<CustomTable> getData = groupParticipationorganizerrepo.getaa();
	 return getData;
}


//to get data by theme and org id
@RequestMapping(value = "/getdata-theme-org",method = RequestMethod.POST)
public List<CustomTable> getdatabythorg(CustomTableData obj) {
//	Integer start  = obj.getStart();
//	Integer length = obj.getLength();
	Integer theme_id = obj.getTheme_id();
	Integer organizer_id = obj.getOrganizer_id();
	System.out.println(obj.getOrganizer_id());
	System.out.println(obj.getTheme_id());
	List<CustomTable> data;
//	int num = (Integer) null;
//	String s = Integer.toString(num);
	if(theme_id == null && organizer_id==null) {
		data = groupParticipationorganizerrepo.getaa();
	}
	else if(obj.getOrganizer_id()!= null && theme_id == null) {
		data =groupParticipationorganizerrepo.getdatabyorganizer( organizer_id);
	}else if (organizer_id==null && obj.getTheme_id() != null) {
		data =groupParticipationorganizerrepo.getdatabytheme( theme_id);
	}
	else {
		data = groupParticipationorganizerrepo.getdatabyid( theme_id, organizer_id );
	}
	return data;
}


@GetMapping("/get-theme")
public List<GetTheme> gettheme() {
//	Theme theme = new Theme();
//	theme.getName();
//	System.out.println("jj"+theme.getName());
	 List<GetTheme> names = themerepo.getSchoolIdAndName();
//	 List<Object> id = themerepo.getid();
//System.out.println(id);
	    return names;
//	return themerepo.findAll();
}



//@GetMapping("/get-count")
//	public Theme getcount(){
//		Theme obj = new Theme();
//		for (int i = 0; i < obj.getName() i++) {
//		obj.getName();
//		return obj;
//	}









}
