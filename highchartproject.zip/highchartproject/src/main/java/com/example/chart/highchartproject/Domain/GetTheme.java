package com.example.chart.highchartproject.Domain;

public interface GetTheme {
String getname();
Long getid();
}
