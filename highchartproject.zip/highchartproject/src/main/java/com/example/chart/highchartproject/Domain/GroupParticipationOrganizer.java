package com.example.chart.highchartproject.Domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_group_participation_organizer")
public class GroupParticipationOrganizer {
	@Id
Long id;
	
	Long group_participation;
  Long organizer ;         
	String alternate_organizer;
	String created_by;  
	Date created_date;  
	Date last_modified_date ;
	
	
	

	public Long getGroup_participation() {
		return group_participation;
	}

	public void setGroup_participation(Long group_participation) {
		this.group_participation = group_participation;
	}

	public Long getOrganizer() {
		return organizer;
	}

	public void setOrganizer(Long organizer) {
		this.organizer = organizer;
	}

	public String getAlternate_organizer() {
		return alternate_organizer;
	}

	public void setAlternate_organizer(String alternate_organizer) {
		this.alternate_organizer = alternate_organizer;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getLast_modified_date() {
		return last_modified_date;
	}

	public void setLast_modified_date(Date last_modified_date) {
		this.last_modified_date = last_modified_date;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
