package com.example.chart.highchartproject.Domain;

public interface CustomData {
	 String gettheme();
	    Long getCount();
}
