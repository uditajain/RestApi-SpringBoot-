package com.example.chart.highchartproject.Domain;

public class Tbl_group_participation {

}
