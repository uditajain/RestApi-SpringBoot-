package com.example.chart.highchartproject.Domain;

import java.util.List;

public interface CustomOrg {
	
	 String getname();
	 Long getorganizerCount();

}
