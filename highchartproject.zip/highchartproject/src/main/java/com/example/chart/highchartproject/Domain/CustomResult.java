package com.example.chart.highchartproject.Domain;

import java.util.List;

public class CustomResult {
	String name;
	private List<String> organizerCount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getOrganizerCount() {
		return organizerCount;
	}
	public void setOrganizerCount(List<String> organizerCount) {
		this.organizerCount = organizerCount;
	}
	
	
	
	
}
