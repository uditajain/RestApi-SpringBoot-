package com.example.chart.highchartproject.Domain;

public class CustomOrgtheme {
	Long theme_id;
	Long org_id;
	public Long getTheme_id() {
		return theme_id;
	}
	public void setTheme_id(Long theme_id) {
		this.theme_id = theme_id;
	}
	public Long getOrg_id() {
		return org_id;
	}
	public void setOrg_id(Long org_id) {
		this.org_id = org_id;
	}
	
	

}
