package com.example.chart.highchartproject.Repostiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.chart.highchartproject.Domain.GetTheme;
import com.example.chart.highchartproject.Domain.Theme;

public interface ThemeRepo extends JpaRepository<Theme, Long>{
	  @Query("select s.id as id,  s.name as name from Theme s")
	    List<GetTheme> getSchoolIdAndName();
	  @Query("select  s.id from Theme s")
	    List<Object> getid();
}
