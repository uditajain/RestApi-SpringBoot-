package com.example.chart.highchartproject.Repostiory;

public interface CustomTable {
Long getid();
String getorganizer();
String gettheme();
String getadult_male();
String getadult_female();
String getchildren_male();
String getchildren_female();
}
