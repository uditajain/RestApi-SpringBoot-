package com.example.chart.highchartproject.Domain;

public class Custom {
Long count;
String name;
public Long getCount() {
	return count;
}
public void setCount(Long count) {
	this.count = count;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
