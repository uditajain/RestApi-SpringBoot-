package com.example.chart.highchartproject.Domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="tbl_group_participation_theme")
public class GroupParticipationTheme {

	@Id
	Long id;
	
	Long theme ;
	Long group_participation  ;
	String created_by ;        
	Date created_date;  
 Date last_modified_date ;
	
	



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTheme() {
		return theme;
	}

	public void setTheme(Long theme) {
		this.theme = theme;
	}

	public Long getGroup_participation() {
		return group_participation;
	}

	public void setGroup_participation(Long group_participation) {
		this.group_participation = group_participation;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getLast_modified_date() {
		return last_modified_date;
	}

	public void setLast_modified_date(Date last_modified_date) {
		this.last_modified_date = last_modified_date;
	}
	
	
}
