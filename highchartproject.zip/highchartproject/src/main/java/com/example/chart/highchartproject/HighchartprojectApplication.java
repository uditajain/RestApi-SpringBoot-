package com.example.chart.highchartproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HighchartprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HighchartprojectApplication.class, args);
	}

}
