package com.example.chart.highchartproject.Repostiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.chart.highchartproject.Domain.Survey;

public interface SurveyRepostiroy extends JpaRepository<Survey,Long>{

}
