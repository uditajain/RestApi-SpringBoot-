package com.example.chart.highchartproject.Repostiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.chart.highchartproject.Domain.CustomData;
import com.example.chart.highchartproject.Domain.CustomOrg;
import com.example.chart.highchartproject.Domain.GroupParticipationOrganizer;

public interface GroupParticipationOrganizerRepo extends JpaRepository<GroupParticipationOrganizer,Long>{
//	  @Query("select  g.theme from GroupParticipationOrganizer g")
//	  void gettheme();
	
	@Query(value = "select tbl_organizer.name , tbl_organizer.description where (:org_id is null or tbl_organizer.id = :org_id)",nativeQuery = true)
	List<Object> getdata(@Param("org_id")Integer org_id);
	  
//@Query(value = "select tbl_organizer.name as organizer,COUNT(tbl_group_participation_organizer.group_participation) as Count from tbl_group_participation_organizer JOIN tbl_organizer ON tbl_organizer.id=tbl_group_participation_organizer.organizer GROUP BY tbl_organizer.name",nativeQuery = true)
//List<CustomOrg> getCountt();
	
	
@Query(value = "select tbl_organizer.name as name,"
		+ "COUNT(tbl_group_participation_organizer.organizer) as organizerCount "
		+ "from tbl_group_participation_organizer"
		+ " JOIN tbl_organizer ON tbl_organizer.id=tbl_group_participation_organizer.organizer"
		+ " where tbl_organizer.id = :organizer_id"
		+ " GROUP BY tbl_organizer.name",nativeQuery = true)
List<CustomOrg> getCountt(@Param("organizer_id")Long org_id);

@Query(value = "select tbl_organizer.name as name,"
		+ "COUNT(tbl_group_participation_organizer.organizer) as organizerCount "
		+ "from tbl_group_participation_organizer"
		+ " JOIN tbl_organizer ON tbl_organizer.id=tbl_group_participation_organizer.organizer"
		+ " GROUP BY tbl_organizer.name",nativeQuery = true)
List<CustomOrg> getorg();


@Query(value = "select p.id as id, p.children_male as children_male,p.children_female as children_female, p.adult_male as adult_male,p.adult_female as adult_female ,GROUP_CONCAT(op.name SEPARATOR ',') as organizer ,GROUP_CONCAT(th.name SEPARATOR ',') as theme from tbl_group_participation p inner join tbl_group_participation_theme t on t.group_participation = p.id inner join tbl_group_participation_organizer o on o.group_participation = p.id inner join tbl_theme th on th.id = t.theme inner join tbl_organizer op on op.id = o.organizer GROUP BY p.id  " ,nativeQuery = true)
//@Query(value="select p.id, p.children_male,p.children_female, p.adult_male,p.adult_female,GROUP_CONCAT(op.name SEPARATOR ',') as organizer ,GROUP_CONCAT(th.name SEPARATOR ',') as theme from tbl_group_participation p join tbl_group_participation_theme t on t.group_participation = p.id join tbl_group_participation_organizer o on o.group_participation = p.id join tbl_theme th on th.id = t.theme join tbl_organizer op on op.id = o.organizer  GROUP BY p.id")
List<CustomTable> getaa();

//LIMIT :start, :length
//select p.id,GROUP_CONCAT(op.name SEPARATOR ',') as organizer ,GROUP_CONCAT(th.name SEPARATOR ',') as theme from tbl_group_participation p  inner join tbl_group_participation_theme t on t.group_participation = p.id  inner join tbl_group_participation_organizer o on o.group_participation = p.id inner join tbl_theme th on th.id = t.theme inner join tbl_organizer op on op.id = o.organizer
//GROUP BY p.id limit 4;


//to get the data acc to organizer and theme id
@Query(value = "select p.id as id, p.children_male as children_male,p.children_female as children_female, p.adult_male as adult_male,p.adult_female as adult_female , GROUP_CONCAT(op.name SEPARATOR ',') as organizer , GROUP_CONCAT(th.name SEPARATOR ',') as theme from tbl_group_participation p  inner join tbl_group_participation_theme t on t.group_participation = p.id  inner join tbl_group_participation_organizer o on o.group_participation = p.id   inner join tbl_theme th on th.id = t.theme   inner join tbl_organizer op on op.id = o.organizer where  t.theme= :theme_id and o.organizer = :organizer_id  GROUP BY p.id",nativeQuery = true)
List<CustomTable> getdatabyid( @Param("theme_id") Integer theme_id,@Param("organizer_id") Integer organizer_id);


@Query(value = "select p.id as id, p.children_male as children_male,p.children_female as children_female, p.adult_male as adult_male,p.adult_female as adult_female , GROUP_CONCAT(op.name SEPARATOR ',') as organizer , GROUP_CONCAT(th.name SEPARATOR ',') as theme from tbl_group_participation p  inner join tbl_group_participation_theme t on t.group_participation = p.id  inner join tbl_group_participation_organizer o on o.group_participation = p.id   inner join tbl_theme th on th.id = t.theme   inner join tbl_organizer op on op.id = o.organizer where  t.theme= :theme_id  GROUP BY p.id ",nativeQuery = true)
List<CustomTable> getdatabytheme( @Param("theme_id") Integer theme_id);


@Query(value = "select p.id as id, p.children_male as children_male,p.children_female as children_female, p.adult_male as adult_male,p.adult_female as adult_female , GROUP_CONCAT(op.name SEPARATOR ',') as organizer , GROUP_CONCAT(th.name SEPARATOR ',') as theme from tbl_group_participation p  inner join tbl_group_participation_theme t on t.group_participation = p.id  inner join tbl_group_participation_organizer o on o.group_participation = p.id   inner join tbl_theme th on th.id = t.theme   inner join tbl_organizer op on op.id = o.organizer where o.organizer = :organizer_id  GROUP BY p.id ",nativeQuery = true)
List<CustomTable> getdatabyorganizer( @Param("organizer_id") Integer organizer_id);


	
}
