package com.example.chart.highchartproject.Domain;

public interface GetOrganizer {
	String getname();
	Long getid();

}
