package com.example.chart.highchartproject.Domain;

public class PieChart {

}
