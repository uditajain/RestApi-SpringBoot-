package com.example.chart.highchartproject.Repostiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.chart.highchartproject.Domain.GetOrganizer;
import com.example.chart.highchartproject.Domain.Organizer;

public interface OrganizeRepo extends JpaRepository<Organizer, Long> {
	  @Query("select  s.name as name, s.id as id from Organizer s")
	    List<GetOrganizer> getName();
	  @Query("select  s.id from Organizer s")
	    List<GetOrganizer> getid();

}
