package com.example.chart.highchartproject.Repostiory;

public interface PieChartRepository {

}
