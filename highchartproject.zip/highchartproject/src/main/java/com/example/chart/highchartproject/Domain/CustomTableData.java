package com.example.chart.highchartproject.Domain;

public class CustomTableData {

	Integer start;
	Integer length;
	Integer theme_id;
	Integer organizer_id;
	
//	Integer theme_id;
	
public Integer getTheme_id() {
		return theme_id;
	}
	public void setTheme_id(Integer theme_id) {
		this.theme_id = theme_id;
	}
	public Integer getOrganizer_id() {
		return organizer_id;
	}
	public void setOrganizer_id(Integer organizer_id) {
		this.organizer_id = organizer_id;
	}
	//	public Integer getTheme_id() {
//		return theme_id;
//	}
//	public void setTheme_id(Integer theme_id) {
//		this.theme_id = theme_id;
//	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getLength() {
		return length;
	}
	public void setLength(Integer length) {
		this.length = length;
	}



}
