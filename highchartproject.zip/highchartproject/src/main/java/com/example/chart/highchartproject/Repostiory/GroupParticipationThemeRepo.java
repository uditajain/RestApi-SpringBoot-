package com.example.chart.highchartproject.Repostiory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.chart.highchartproject.Domain.CustomData;
import com.example.chart.highchartproject.Domain.GroupParticipationTheme;

public interface GroupParticipationThemeRepo extends JpaRepository<GroupParticipationTheme, Long>{
	  @Query("select  g.theme from GroupParticipationTheme g")
	    List<Object> gettheme();

//	  
//	  @Query(value = "select theme as theme , count(*) as count from tbl_group_participation_theme group by theme")
//	  public List<Map<String,Object>> find();
	  
@Query(value = "select tbl_theme.name as theme,COUNT(tbl_group_participation_theme.theme) as Count from tbl_group_participation_theme JOIN tbl_theme ON tbl_theme.id=tbl_group_participation_theme.theme GROUP BY tbl_theme.name",nativeQuery = true)
List<CustomData> getCountJoin();

//	  @Query(value = "select DISTINCT(tbl_theme.name) as theme from tbl_group_participation_theme JOIN tbl_theme ON tbl_theme.id=tbl_group_participation_theme.theme",nativeQuery = true)
//	  List<CustomData> getCountJoin();
//	  



@Query(value = "select tbl_theme.name as theme,COUNT(tbl_group_participation_theme.theme) as Count from tbl_group_participation_theme JOIN tbl_theme ON tbl_theme.id=tbl_group_participation_theme.theme where tbl_group_participation_theme.theme = :theme_id GROUP BY tbl_theme.name",nativeQuery = true)
List<CustomData> getCountJoinbyid(@Param("theme_id")Long theme_id);
}
